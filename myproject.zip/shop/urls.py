from django.urls import path
from . import views
urlpatterns = [
    path('', views.shop, name='shop'),
    path('home/', views.home, name='home'),
]