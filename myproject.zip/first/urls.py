from django.urls import path
from . import views
urlpatterns = [
    path('', views.my_view, name='my_view'),
    path('my_db/', views.my_db, name='my_db'),
]