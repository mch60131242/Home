from django.db import models

# Create your models here.
# models.py
class Employee(models.Model):
    first_name = models.CharField(max_length=50)
    age = models.IntegerField()
    salary = models.FloatField()

    emp_no = models.IntegerField()
    birth_date = models.DateField()
    first_name = models.CharField(max_length=14)
    last_name = models.CharField(max_length=16)
    gender = models.CharField(max_length=1)
    hire_date = models.DateField()

    class Meta:
        db_table = 'employees'

# views.py


