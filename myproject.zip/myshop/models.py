from django.db import models

# Create your models here.
class Actor(models.Model):  # table의 컬럼 및 함수 정의
    actor_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    last_update = models.DateTimeField()

    class Meta:
        db_table = 'actor'
        app_label = 'myshop'
        # using = 'sakila'
        managed = False

    # # Set the database name for this model
    @classmethod
    def get_all(cls):
        return cls.objects.using('sakila').all()


class Member(models.Model):  # table의 컬럼 및 함수 정의
    member_id = models.CharField(primary_key=True, max_length=10)
    member_name = models.CharField(max_length=20)
    member_passwd = models.CharField(max_length=20)
    member_email = models.CharField(max_length=40)
    member_hp = models.CharField(max_length=16)
    member_indate = models.DateField(auto_now=True)

    class Meta:
        db_table = 'member'
        app_label = 'myshop'
        managed = False

    # # Set the database name for this model
    @classmethod
    def get_all(cls):
        return cls.objects.using('mydb').all()
