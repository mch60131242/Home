from  django.urls import path
from . import views

urlpatterns = [
    path('my_actor', views.my_actor, name='my_actor'),
    path('my_dbconn', views.my_dbconn, name='my_dbconn'),
    path('', views.login_view, name='login'),
]