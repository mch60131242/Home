from django.shortcuts import render

from .models import Employee
# Create your views here.

import mysql.connector
def shop(request):
    # MySQL 데이터베이스에 연결
    conn = mysql.connector.connect(
      host="localhost",
      user="root",
      password="passwd",
      database="employees"
    )

    # cursor 객체 생성
    cursor = conn.cursor()

    # SELECT 쿼리 실행
    cursor.execute("SELECT first_name FROM employees limit 10")

    # 결과 가져오기
    result = cursor.fetchall()

    # 결과 출력
    for row in result:
      print(row)

    context = {'results': result}
    return render(request, 'test.html', context)


def home(request):
    # MySQL 데이터베이스에서 Employee 모델의 모든 객체 가져오기
    employees = Employee.objects.all()

    # HTML 페이지 출력
    context = {'employees': employees}
    return render(request, 'home.html', context)