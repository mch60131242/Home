from django.shortcuts import render

# Create your views here.
from myshop.models import Actor
def my_actor(request):
    rows = Actor.objects.all().using('sakila')
    # rows = Actor.objects.all()

    return render(request, 'myactor.html', {'rows':rows})

import MySQLdb
def my_dbconn(request):   # db connect , cursor 사용
    conn = MySQLdb.connect(
        host = 'localhost',
        user = 'root',
        passwd = 'passwd',
        db = 'sakila'
    )

    # create cursor, select query
    cur = conn.cursor()
    sql = 'select actor_id, first_name, last_name from actor limit 100'
    cur.execute(sql)
    rows = cur.fetchall()

    conn.close()
    return render(request, 'myactor_1.html', {'rows':rows})

from django.contrib.auth import authenticate, login
from django.shortcuts import render, HttpResponseRedirect, reverse
from django.http import HttpResponse

def mydb_connect():
    conn = MySQLdb.connect(
        host = 'localhost',
        user = 'root',
        passwd = 'passwd',
        db = 'mydb'
    )
    return conn

def login_view(request):
    if request.method == 'POST':
        # POST 요청에서 user_id와 user_passwd 값을 가져옴
        conn = mydb_connect()
        cur = conn.cursor()
        member_id = request.POST.get('id')
        member_passwd = request.POST.get('pw')
        sql = '''
            select member_id, member_passwd, member_name 
            from member 
            where member_id = %s
            and member_passwd = %s
            '''
        cur.execute(sql, (member_id, member_passwd))
        user = cur.fetchone()
        conn.close()
        if user is not None:
            # 인증 성공한 경우 로그인 처리
            return render(request, 'abcd.html', {'name': user[2]})
        else:
            return render(request, 'main.html', {'error': 'ID 또는 비밀번호가 올바르지 않습니다.'})
    else:
        # GET 요청인 경우 로그인 페이지를 보여줌
        return render(request, 'main.html')



