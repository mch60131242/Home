from django.shortcuts import render

# Create your views here.
# import json
from django.http import HttpResponse

def my_view(request):
    # do some processing
    # data = {'message': '한글 !'}
    # json_data = json.dumps(data)
    # return HttpResponse(json_data, content_type='application/json')
    html = '장고 환영'
    return HttpResponse(html)


from django.http import HttpResponse
import MySQLdb

def my_db(request):
    # Create a database connection object
    conn = MySQLdb.connect(
        host="localhost",
        user="myusername",
        passwd="mypassword",
        db="mydatabase"
    )

    # Create a cursor object and execute a SELECT query
    cur = conn.cursor()
    cur.execute("SELECT * FROM mytable")
    rows = cur.fetchall()

    # Build an HTML string to display the results
    html = "<h1>MyTable Records</h1>"
    html += "<ul>"
    for row in rows:
        html += "<li>{0} - {1} - {2}</li>".format(row[0], row[1], row[2])
    html += "</ul>"

    # Close the database connection
    conn.close()

    # Return an HTTP response with the HTML string
    return HttpResponse(html)
